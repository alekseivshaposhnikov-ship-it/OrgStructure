/**
 * compact-a4-svg-renderer.js
 *
 * Рисует компактную orgchart-диаграмму в SVG для A4 landscape.
 * Раздельные renderer'ы: department, employee, vacancy, assistant.
 */

import { A4_WIDTH, A4_HEIGHT, PADDING_X, PERSON_H } from './compact-a4-layout.js';
import { COLORS } from '../tokens.js';
import { createSvgElement as createSvg, addText, truncateText } from '../svg-utils.js';
import { getLayoutDebugText } from '../chart-cards.js';

const C = { ...COLORS };

export function renderCompactSvg(layoutResult, options = {}) {
  const { title = 'Организационная структура', subtitle = '', screen = false } = options;
  const { flat, scale, a4Width, a4Height, canFit } = layoutResult;

  if (!canFit || !flat || !flat.length) {
    return renderError('Структуру невозможно уместить на один лист A4 без потери читаемости');
  }

  const svg = createSvg('svg', {
    width: screen ? '100%' : a4Width,
    height: screen ? '100%' : a4Height,
    viewBox: `0 0 ${a4Width} ${a4Height}`,
    xmlns: 'http://www.w3.org/2000/svg',
    class: screen ? 'compact-a4' : '',
  });
  svg.appendChild(createSvg('rect', { x: 0, y: 0, width: a4Width, height: a4Height, fill: C.white }));
  // Экранный заголовок A4 остаётся фиксированным (не двигается вместе с zoom/pan).
  drawHeader(svg, { title, subtitle, width: a4Width });

  const diag = createSvg('g', {
    transform: scale !== 1 ? `translate(0,0) scale(${scale})` : 'translate(0,0)',
  });

  const nodesMap = new Map(flat.map(n => [n.id, n]));
  drawAllConnectors(diag, flat, nodesMap);

  flat.forEach(n => {
    if (n.type === 'department') drawDeptCard(diag, n);
    else if (n.type === 'vacancy') drawVacancyCard(diag, n);
    else if (n.type === 'assistant') drawAssistantCard(diag, n);
    else if (n.type === 'employees') drawEmployeesColumn(diag, n);
    else drawEmployeeCard(diag, n);
  });

  if (screen) {
    // Экранный режим: диаграмма живёт в отдельном слое, к которому
    // применяется общий viewport transform (zoom/pan).
    const viewportLayer = createSvg('g', { class: 'compact-a4__viewport-layer' });
    viewportLayer.appendChild(diag);
    svg.appendChild(viewportLayer);
  } else {
    svg.appendChild(diag);
  }
  return svg;
}

// === Связи ===

function drawAllConnectors(group, flat, map) {
  const byParent = new Map();
  flat.forEach(n => { if (n.parentId) { const a = byParent.get(n.parentId) || []; a.push(n); byParent.set(n.parentId, a); } });

  byParent.forEach((children, pid) => {
    const p = map.get(pid); if (!p) return;

    // CR-015 §8-9 + CR-019 §21-22: короткая связь manager → assistant.
    // side (top-management): right-center manager → left-center assistant;
    // below (обычные руководители): вертикальная bottom-center → top-center.
    const assistants = children.filter(c => c.type === 'assistant');
    assistants.forEach(a => {
      if (p.assistantPlacement === 'side') {
        const fromX = p.x + p.cardWidth;
        const fromY = p.y + p.cardHeight / 2;
        const toX = a.x;
        const toY = a.y + a.cardHeight / 2;
        const midX = fromX + (toX - fromX) / 2;
        const d = Math.abs(toY - fromY) < 1
          ? `M ${fromX} ${fromY} L ${toX} ${toY}`
          : `M ${fromX} ${fromY} L ${midX} ${fromY} L ${midX} ${toY} L ${toX} ${toY}`;
        group.appendChild(createSvg('path', { d, fill: 'none', stroke: C.line, 'stroke-width': 1.5 }));
      } else {
        const fromX = p.x + p.cardWidth / 2;
        const fromY = p.y + p.cardHeight;
        const toX = a.x + a.cardWidth / 2;
        const toY = a.y;
        group.appendChild(createSvg('path', {
          d: `M ${fromX} ${fromY} L ${toX} ${toY}`,
          fill: 'none',
          stroke: C.line,
          'stroke-width': 1.5,
        }));
      }
    });

    const orgChildren = children.filter(c => c.type !== 'assistant');
    if (!orgChildren.length) return;

    const px = p.x + p.cardWidth / 2;
    const py = p.y + p.cardHeight;
    if (orgChildren.length === 1) {
      const c = orgChildren[0];
      drawPath(group, px, py, c.x + c.cardWidth / 2, c.y);
      return;
    }
    const sorted = [...orgChildren].sort((a, b) => a.y - b.y);
    const first = sorted[0];
    const trunkY = py + (first.y - py) / 2;
    drawPath(group, px, py, px, trunkY);
    let minX = Infinity, maxX = -Infinity;
    orgChildren.forEach(c => { const cx = c.x + c.cardWidth / 2; if (cx < minX) minX = cx; if (cx > maxX) maxX = cx; });
    drawPath(group, minX, trunkY, maxX, trunkY);
    orgChildren.forEach(c => drawPath(group, c.x + c.cardWidth / 2, trunkY, c.x + c.cardWidth / 2, c.y));
  });
}

function drawPath(g, x1, y1, x2, y2) {
  const d = x1 === x2 ? `M ${x1} ${y1} L ${x2} ${y2}`
    : `M ${x1} ${y1} V ${y1 + (y2 - y1) / 2} H ${x2} V ${y2}`;
  g.appendChild(createSvg('path', { d, fill: 'none', stroke: C.line, 'stroke-width': 1.5 }));
}

// === Карточки ===

function drawDeptCard(g, n) {
  const grp = createSvg('g', { transform: `translate(${n.x}, ${n.y})` });
  grp.appendChild(createSvg('rect', { x: 0, y: 0, width: n.cardWidth, height: n.cardHeight, rx: 8, ry: 8, fill: C.deptBg, stroke: C.blue, 'stroke-width': 2 }));
  if (n.scenarioState) drawBadge(grp, n.scenarioState);

  drawText(grp, n.name, { x: 10, y: n.scenarioState ? 26 : 16, maxW: n.cardWidth - 20, fontSize: 11, fw: 600, fill: C.text, maxLines: 2, lineH: 13 });
  if (n.manager) drawText(grp, n.manager, {
    x: 10, y: n.scenarioState ? 42 : 32,
    maxW: n.cardWidth - 60, fontSize: 9, fw: 400, fill: '#344054', maxLines: 1, lineH: 11,
  });
  if (n.position) {
    const posY = n.manager ? (n.scenarioState ? 54 : 44) : (n.scenarioState ? 42 : 32);
    if (posY < n.cardHeight - 4) drawText(grp, n.position, {
      x: 10, y: posY, maxW: n.cardWidth - 60, fontSize: 8, fw: 400, fill: C.muted, maxLines: 1, lineH: 10,
    });
  }
  if (n.count != null) {
    grp.appendChild(createSvg('rect', { x: n.cardWidth - 34, y: n.cardHeight - 20, width: 24, height: 14, rx: 7, ry: 7, fill: C.blueLight }));
    addText(grp, String(n.count), n.cardWidth - 22, n.cardHeight - 9, 8, 700, C.blue, 'middle');
  }
  if (n.project) {
    grp.appendChild(createSvg('rect', { x: 6, y: n.cardHeight - 20, width: Math.min(n.cardWidth - 60, 120), height: 14, rx: 7, ry: 7, fill: '#f2f4f7' }));
    addText(grp, `П: ${truncateText(n.project, 18)}`, 12, n.cardHeight - 9, 7, 400, '#475467');
  }
  // Диагностика уровней (CR-010 §10): компактная строка, не меняет высоту карточки
  const layoutDebug = getLayoutDebugText(n, { compact: true });
  if (layoutDebug) {
    addText(grp, layoutDebug, 4, n.cardHeight - 1, 5, 400, C.muted);
  }
  g.appendChild(grp);
}

function drawEmployeeCard(g, n) {
  const grp = createSvg('g', { transform: `translate(${n.x}, ${n.y})` });
  grp.appendChild(createSvg('rect', { x: 0, y: 0, width: n.cardWidth, height: n.cardHeight, rx: 5, ry: 5, fill: C.white, stroke: C.border, 'stroke-width': 1 }));
  if (n.scenarioState) drawBadge(grp, n.scenarioState);

  const nameY = n.scenarioState ? 22 : 13;
  drawText(grp, n.name, { x: 8, y: nameY, maxW: n.cardWidth - 16, fontSize: 9, fw: 600, fill: C.text, maxLines: 2, lineH: 11 });
  if (n.position) {
    const posY = nameY + (n.name ? 13 : 0);
    if (posY < n.cardHeight - 4) drawText(grp, n.position, {
      x: 8, y: posY, maxW: n.cardWidth - 16, fontSize: 7, fw: 400, fill: C.muted, maxLines: 1, lineH: 9,
    });
  }
  if (n.project) {
    grp.appendChild(createSvg('rect', { x: 4, y: n.cardHeight - 14, width: Math.min(n.cardWidth - 30, 100), height: 10, rx: 5, ry: 5, fill: '#f2f4f7' }));
    addText(grp, `П: ${truncateText(n.project, 14)}`, 8, n.cardHeight - 6, 6, 400, '#475467');
  }
  g.appendChild(grp);
}

function drawVacancyCard(g, n) {
  const grp = createSvg('g', { transform: `translate(${n.x}, ${n.y})` });
  grp.appendChild(createSvg('rect', { x: 0, y: 0, width: n.cardWidth, height: n.cardHeight, rx: 5, ry: 5, fill: C.vacancyBg, stroke: C.vacancyStroke, 'stroke-width': 1.5 }));
  addText(grp, 'Вакансия', 8, 14, 9, 700, C.blue);
  if (n.position) drawText(grp, n.position, { x: 8, y: 26, maxW: n.cardWidth - 16, fontSize: 7, fw: 400, fill: C.muted, maxLines: 1, lineH: 9 });
  g.appendChild(grp);
}

function drawAssistantCard(g, n) {
  const grp = createSvg('g', { transform: `translate(${n.x}, ${n.y})` });
  grp.appendChild(createSvg('rect', { x: 0, y: 0, width: n.cardWidth, height: n.cardHeight, rx: 5, ry: 5, fill: C.assistantBg, stroke: C.assistantStroke, 'stroke-width': 1.5 }));
  addText(grp, 'Адм. ассистент', 8, 14, 8, 600, C.assistantStroke);

  // CR-020 §6: сгруппированные административные ассистенты рисуются в одной
  // карточке — каждый участник отдельной строкой без наложения.
  if (Array.isArray(n.members) && n.members.length > 1) {
    let y = 26;
    n.members.forEach((member) => {
      if (member.name) {
        drawText(grp, member.name, { x: 8, y, maxW: n.cardWidth - 16, fontSize: 7, fw: 400, fill: C.text, maxLines: 1, lineH: 9 });
      }
      y += 12;
    });
  } else if (n.name) {
    drawText(grp, n.name, { x: 8, y: 26, maxW: n.cardWidth - 16, fontSize: 7, fw: 400, fill: C.text, maxLines: 1, lineH: 9 });
  }
  g.appendChild(grp);
}

function drawEmployeesColumn(g, n) {
  const grp = createSvg('g', { transform: `translate(${n.x}, ${n.y})` });
  grp.appendChild(createSvg('rect', {
    x: 0, y: 0, width: n.cardWidth, height: n.cardHeight,
    rx: 8, ry: 8, fill: '#f8fafc', stroke: '#cbd5e1',
    'stroke-width': 1, 'stroke-dasharray': '4 3',
  }));
  addText(grp, n.header || 'Сотрудники', n.cardWidth / 2, 14, 8, 700, '#475467', 'middle');

  let y = 22;
  (n.persons || []).forEach(person => {
    const card = { ...person, x: 0, y };
    if (person.type === 'vacancy') drawVacancyCard(grp, card);
    else drawEmployeeCard(grp, card);
    y += (person.cardHeight || PERSON_H) + 4;
  });

  g.appendChild(grp);
}

// === Утилиты ===

function drawBadge(g, state) {
  const lbl = {added:'NEW',changed:'Изм',moved:'Пер',removed:'Удал'}[state] || '';
  const clr = {added:{bg:C.addedBg,txt:C.addedText},changed:{bg:C.changedBg,txt:C.changedText},moved:{bg:C.movedBg,txt:C.movedText},removed:{bg:C.removedBg,txt:C.removedText}}[state] || {bg:'#f2f4f7',txt:'#344054'};
  g.appendChild(createSvg('rect', { x: 6, y: 5, width: lbl.length * 6 + 10, height: 13, rx: 6.5, ry: 6.5, fill: clr.bg }));
  addText(g, lbl, 11, 15, 7, 700, clr.txt);
}

function drawText(g, text, { x, y, maxW, fontSize, fw, fill, maxLines = 2, lineH }) {
  const lines = wrap(String(text || ''), maxW, fontSize, maxLines);
  lines.forEach((l, i) => addText(g, l, x, y + i * lineH, fontSize, fw, fill));
}

function wrap(text, maxW, fontSize, maxLines) {
  const cw = fontSize * 0.53;
  const maxLen = Math.max(4, Math.floor(maxW / cw));
  const words = text.split(/\s+/).filter(Boolean);
  if (!words.length) return [''];
  const lines = [];
  let cur = '';
  for (const w of words) {
    const nxt = cur ? `${cur} ${w}` : w;
    if (nxt.length > maxLen) {
      if (cur) { lines.push(cur); cur = w; }
      else {
        // Одно слово длиннее maxLen — обрезаем
        let leftover = w;
        while (leftover.length > maxLen) {
          lines.push(leftover.slice(0, maxLen));
          leftover = leftover.slice(maxLen);
          if (lines.length >= maxLines) break;
        }
        cur = leftover || '';
      }
    } else { cur = nxt; }
    if (lines.length >= maxLines) break;
  }
  if (cur && lines.length < maxLines) lines.push(cur);
  if (lines.length > maxLines) lines.splice(maxLines);
  if (lines.length > 0 && lines.length >= maxLines) {
    const last = lines[lines.length - 1];
    if (last.length > 2) lines[lines.length - 1] = last.slice(0, -1) + '…';
  }
  return lines.length ? lines : [''];
}

function drawHeader(svg, { title, subtitle, width }) {
  addText(svg, 'Организационная структура', PADDING_X, 24, 10, 700, C.blue);
  addText(svg, title, PADDING_X, 42, 18, 700, C.text);
  if (subtitle) addText(svg, subtitle, PADDING_X, 58, 10, 400, C.muted);
  addText(svg, new Intl.DateTimeFormat('ru-RU', { day:'2-digit', month:'2-digit', year:'numeric' }).format(new Date()), width - PADDING_X, 42, 10, 400, C.muted, 'end');
  svg.appendChild(createSvg('line', { x1: PADDING_X, y1: 72, x2: width - PADDING_X, y2: 72, stroke: '#e4e7ec', 'stroke-width': 1 }));
}

function renderError(msg) {
  const s = createSvg('svg', { width: A4_WIDTH, height: A4_HEIGHT, viewBox: `0 0 ${A4_WIDTH} ${A4_HEIGHT}`, xmlns: 'http://www.w3.org/2000/svg' });
  s.appendChild(createSvg('rect', { x: 0, y: 0, width: A4_WIDTH, height: A4_HEIGHT, fill: C.white }));
  addText(s, msg, A4_WIDTH / 2, A4_HEIGHT / 2, 16, 700, '#f04438', 'middle');
  return s;
}