import { shortPosition, parseSubLevel } from "../core/utils/tree.js";
import { sortUsersByPositionLevel } from "../core/utils/position.js";
import { isEmployeeExcludedByState, shouldKeepFullName } from "../core/utils/employee.js";

// Единый список исключаемых подразделений (CR-006, CR-020, CR-021 §2).
// Сравнение идёт по точному значению department_name (без includes/substring).
const EXCLUDED_DEPARTMENTS = new Set([
  "Администрация+",
  "Прочие",
  "Дирекция по продажам",
]);

const RENAMED_DEPARTMENTS = {
  "Дирекция по эксплуатации": "LEGENDA Comfort",
};

export async function fetchOrganizationStructure() {
  const url = "/api/getDepartmentVacancy";

  try {
    const response = await fetch(url, {
      signal: AbortSignal.timeout(30_000),
    });

    if (!response.ok) {
      throw new Error(`Ошибка HTTP: ${response.status} ${response.statusText}`);
    }

    const apiData = await response.json();
    let tree = transformApiResponse(apiData);
    tree = tree.map((node) => applyRenames(node));
    tree = filterExcludedDepartments(tree);
    tree = filterEmptyDepartments(tree);
    return tree;
  } catch (error) {
    console.error("Не удалось загрузить данные структуры:", error);
    alert(
      "Не удалось загрузить организационную структуру. Проверьте доступность сервера.",
    );
    return [];
  }
}

export function filterExcludedDepartments(nodes) {
  if (!Array.isArray(nodes)) return [];
  return nodes
    .filter(
      (node) => !EXCLUDED_DEPARTMENTS.has(node.department_name || ""),
    )
    .map((node) => ({
      ...node,
      children: filterExcludedDepartments(node.children || []),
    }));
}

export function filterEmptyDepartments(nodes) {
  if (!Array.isArray(nodes)) return [];
  return nodes
    .filter((node) => !isDepartmentEmpty(node))
    .map((node) => ({
      ...node,
      children: filterEmptyDepartments(node.children || []),
    }));
}

function isDepartmentEmpty(node) {
  if ((node.staffCount || 0) > 0 || (node.vacancyCount || 0) > 0) return false;

  const filteredChildren = (node.children || []).filter(
    (child) => !isDepartmentEmpty(child),
  );
  return filteredChildren.length === 0;
}

export function applyRenames(node) {
  if (!node) return node;
  const name = node.department_name || "";
  const newName = RENAMED_DEPARTMENTS[name] || name;

  return {
    ...node,
    department_name: newName,
    children: (node.children || []).map((child) => applyRenames(child)),
  };
}

function transformApiResponse(apiNodes) {
  return (apiNodes || []).map((node) => transformNode(node));
}

function parseCount(value) {
  const countStr = value ? String(value).replace(",", ".") : "0";
  return parseFloat(countStr) || 0;
}

function getProject(emp) {
  return (
    emp.projects ||
    emp.project ||
    emp.project_name ||
    emp.projectName ||
    emp.project_title ||
    ""
  );
}

function getPhone(emp) {
  return emp.phone || emp.phone_number || emp.mobile || emp.work_phone || "";
}

function getPhoto(emp) {
  return emp.photo || emp.photo_url || emp.avatar || emp.avatar_url || "";
}

function isSamePerson(emp, manager) {
  if (!manager) return false;

  if (manager.id && emp.id && manager.id === emp.id) return true;

  const empName = String(emp.full_name || "")
    .trim()
    .toLowerCase();
  const managerName = String(manager.full_name || "")
    .trim()
    .toLowerCase();

  return empName && managerName && empName === managerName;
}

function getManagerSubLevel(apiNode) {
  const manager = apiNode.manager;

  if (!manager) {
    return parseSubLevel(undefined);
  }

  if (
    manager.sub_level !== undefined &&
    manager.sub_level !== null &&
    manager.sub_level !== ""
  ) {
    return parseSubLevel(manager.sub_level);
  }

  const managerEmployee = (apiNode.employees || []).find((emp) =>
    isSamePerson(emp, manager),
  );

  return parseSubLevel(managerEmployee?.sub_level);
}

/**
 * CR-016 §12: руководитель подразделения с исключающим статусом не отображается
 * как активный manager. Department продолжает существовать (fallback
 * «Нет руководителя»), другого человека не назначаем автоматически.
 */
function isManagerExcluded(apiNode) {
  const manager = apiNode.manager;
  if (!manager) return false;

  if (isEmployeeExcludedByState(manager)) return true;

  const managerRecord = (apiNode.employees || []).find((emp) =>
    isSamePerson(emp, manager),
  );
  return Boolean(managerRecord && isEmployeeExcludedByState(managerRecord));
}

function transformNode(apiNode, parentId = null) {
  const allEmployees = apiNode.employees || [];

  // CR-016 §2, §5: status filtering ПЕРВЫМ слоем. Сотрудники со статусом
  // «Отпуск по уходу за ребенком» полностью исключаются из оргструктуры ДО
  // counts / users / sourceUsers / manager resolution.
  const structuralEmployees = allEmployees.filter(
    (emp) => !isEmployeeExcludedByState(emp),
  );

  // CR-013_fix §4-5: полный исходный набор сотрудников ДО визуальной фильтрации
  // по count >= 1. Используется ТОЛЬКО для поиска top-management (holding
  // leadership projection): руководители с дробной занятостью (0.02, 0.1, 0.5)
  // не должны теряться. Обычный renderer строит employee columns из node.users.
  // CR-016 §6: excluded сотрудники не попадают в structural sourceUsers.
  const sourceUsers = structuralEmployees.map((emp) => ({
    id: emp.id,
    full_name: emp.full_name,
    name: emp.full_name,
    fullName: emp.full_name,
    email: emp.email || "",
    phone: getPhone(emp),
    photo: getPhoto(emp),
    project: getProject(emp),
    position: shortPosition(emp.position),
    rawPosition: emp.position || "",
    subLevel: parseSubLevel(emp.sub_level),
    typeEmployment: emp.type_employment || "",
    state: emp.state || "",
    count: parseCount(emp.count),
    isVacancy: false,
  }));

  const validEmployees = structuralEmployees.filter(
    (emp) => parseCount(emp.count) >= 1,
  );
  const visibleEmployees = validEmployees.filter(
    (emp) => !isSamePerson(emp, apiNode.manager),
  );

  const users = visibleEmployees.map((emp) => ({
    full_name: emp.full_name,
    email: emp.email || "",
    phone: getPhone(emp),
    photo: getPhoto(emp),
    project: getProject(emp),
    name: emp.full_name,
    fullName: emp.full_name,
    id: emp.id,
    position: shortPosition(emp.position),
    rawPosition: emp.position || "",
    subLevel: parseSubLevel(emp.sub_level),
    typeEmployment: emp.type_employment || "",
    state: emp.state || "",
    isVacancy: false,
    // CR-016 §20, §24: семантический presentation-флаг top-3 (полное ФИО).
    keepFullName: shouldKeepFullName(emp.full_name),
  }));

  const vacancies = (apiNode.vacancy_list || []).map((vac) => ({
    id: vac.id,
    full_name: "Вакансия",
    email: "",
    phone: "",
    photo: "",
    project: getProject(vac),
    name: "Вакансия",
    fullName: "Вакансия",
    position: shortPosition(vac.position),
    rawPosition: vac.position || "",
    subLevel: parseSubLevel(vac.sub_level),
    isVacancy: true,
  }));

  const children = (apiNode.children || []).map((child) =>
    transformNode(child, apiNode.id),
  );

  const ownVacancyCount = vacancies.length;
  const childrenStaffCount = children.reduce(
    (sum, child) => sum + (child.staffCount || 0),
    0,
  );
  const childrenVacancyCount = children.reduce(
    (sum, child) => sum + (child.vacancyCount || 0),
    0,
  );

  const staffCount = validEmployees.length + childrenStaffCount;
  const vacancyCount = ownVacancyCount + childrenVacancyCount;
  const totalWithVacancies = staffCount + vacancyCount;

  // CR-016 §12: руководитель с исключающим статусом не отображается.
  const managerHidden = isManagerExcluded(apiNode);

  return {
    department_guid: apiNode.id,
    department_name: apiNode.name,
    department_manager: managerHidden ? "" : apiNode.manager?.full_name || "",
    department_manager_position: shortPosition(apiNode.manager?.position || ""),
    manager_sub_level: getManagerSubLevel(apiNode),
    parent_guid: parentId,
    // CR-016 §20, §24: presentation-флаг полного ФИО для manager top-3.
    keepFullName: shouldKeepFullName(apiNode.manager?.full_name || ""),
    staffCount,
    vacancyCount,
    totalWithVacancies,
    users: [...users, ...vacancies].sort(sortUsersByPositionLevel),
    // CR-013_fix §5: полный source для top-management поиска (не для рендера).
    sourceUsers,
    children,
  };
}
